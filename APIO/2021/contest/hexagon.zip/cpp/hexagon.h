#include <vector>

int draw_territory(int N, int A, int B, std::vector<int> D, std::vector<int> L);
