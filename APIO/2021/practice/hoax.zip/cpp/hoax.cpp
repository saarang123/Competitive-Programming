#include "hoax.h"

#include <vector>

void init(int N, int S, std::vector<int> T,
          std::vector<std::vector<int>> A, std::vector<std::vector<int>> B) {

}

int count_users(int P) {
  return 0;
}
