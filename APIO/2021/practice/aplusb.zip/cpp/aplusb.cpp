#include "aplusb.h"

int add_two_numbers(int A, int B) {
  return 0;
}
