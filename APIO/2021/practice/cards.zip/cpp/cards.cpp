#include "cards.h"

void init_magician(int N, int K) {
}

void init_assistant(int N, int K) {
}

std::vector<int> choose_cards(std::vector<int> cards) {
  return std::vector<int>((int) cards.size() - 1);
}

int find_discarded_card(std::vector<int> cards) {
  return 1;
}
