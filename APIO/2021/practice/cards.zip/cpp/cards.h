#include <vector>

void init_assistant(int N, int K);
void init_magician(int N, int K);
std::vector<int> choose_cards(std::vector<int> cards);
int find_discarded_card(std::vector<int> cards);
