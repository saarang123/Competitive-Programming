public class swap {
  public void init(int N, int M, int[] U, int[] V, int[] W) {

  }

  public int getMinimumFuelCapacity(int X, int Y) {
    return 0;
  }
}
